/**
 * roles.js - Configuracion de Roles y Permisos (RBAC)
 * Define matriz de permisos para Dueno, Veterinario y Fundacion
 */

export const ROLES = {
  DUENO: "dueno",
  VETERINARIO: "veterinario",
  FUNDACION: "fundacion",
  ADMIN: "admin",
}

export const PERMISOS = {
  // Info Basica (Editable por Dueno)
  EDITAR_INFO_BASICA: {
    campos: ["nombre", "foto", "direccion", "telefonoContacto", "observaciones"],
    roles: [ROLES.DUENO, ROLES.VETERINARIO, ROLES.FUNDACION, ROLES.ADMIN],
  },

  // Info Clinica (Solo Veterinario)
  EDITAR_INFO_CLINICA: {
    campos: ["raza", "peso", "edad", "especie", "sexo", "chip"],
    roles: [ROLES.VETERINARIO, ROLES.ADMIN],
  },

  // Verificacion de Chip (Solo Veterinario)
  VERIFICAR_CHIP: {
    roles: [ROLES.VETERINARIO, ROLES.ADMIN],
  },

  // Agregar Procedimientos (Veterinario)
  AGREGAR_PROCEDIMIENTOS: {
    roles: [ROLES.VETERINARIO, ROLES.ADMIN],
  },

  // Ver todos los companeros (Vista Profesional)
  VER_TODOS_COMPANEROS: {
    roles: [ROLES.VETERINARIO, ROLES.FUNDACION, ROLES.ADMIN],
  },

  // Transferir tutela (Fundacion)
  TRANSFERIR_TUTELA: {
    roles: [ROLES.FUNDACION, ROLES.ADMIN],
  },
}

/**
 * Verifica si un rol tiene permiso para editar un campo especifico
 * @param {string} rol - Rol del usuario actual
 * @param {string} campo - Campo que se intenta editar
 * @returns {boolean}
 */
export function puedeEditarCampo(rol, campo) {
  // Verificar si el campo esta en info basica
  if (PERMISOS.EDITAR_INFO_BASICA.campos.includes(campo)) {
    return PERMISOS.EDITAR_INFO_BASICA.roles.includes(rol)
  }

  // Verificar si el campo esta en info clinica
  if (PERMISOS.EDITAR_INFO_CLINICA.campos.includes(campo)) {
    return PERMISOS.EDITAR_INFO_CLINICA.roles.includes(rol)
  }

  return false
}

/**
 * Verifica si un rol tiene un permiso especifico
 * @param {string} rol - Rol del usuario actual
 * @param {string} permiso - Nombre del permiso (ej: "VERIFICAR_CHIP")
 * @returns {boolean}
 */
export function tienePermiso(rol, permiso) {
  if (!PERMISOS[permiso]) return false
  return PERMISOS[permiso].roles.includes(rol)
}

/**
 * Obtiene los campos editables para un rol especifico
 * @param {string} rol - Rol del usuario actual
 * @returns {string[]} Array de nombres de campos
 */
export function getCamposEditables(rol) {
  const campos = []

  if (PERMISOS.EDITAR_INFO_BASICA.roles.includes(rol)) {
    campos.push(...PERMISOS.EDITAR_INFO_BASICA.campos)
  }

  if (PERMISOS.EDITAR_INFO_CLINICA.roles.includes(rol)) {
    campos.push(...PERMISOS.EDITAR_INFO_CLINICA.campos)
  }

  return campos
}

/**
 * Filtra un objeto de datos para incluir solo campos editables
 * @param {object} data - Datos a filtrar
 * @param {string} rol - Rol del usuario actual
 * @returns {object} Datos filtrados
 */
export function filtrarDatosEditables(data, rol) {
  const camposEditables = getCamposEditables(rol)
  const datosFiltrados = {}

  for (const campo of camposEditables) {
    if (data.hasOwnProperty(campo)) {
      datosFiltrados[campo] = data[campo]
    }
  }

  return datosFiltrados
}
