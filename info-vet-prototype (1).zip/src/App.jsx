"use client"

import { useState, useEffect } from "react"
import { getMascotasByUser } from "./services/api"
import { useAuth } from "./context/AuthContext"
import Login from "./components/Login"
import Register from "./components/Register"
import Dashboard from "./components/Dashboard"
import DetallesMascota from "./components/DetallesMascota"

export default function App() {
  const { usuario: usuarioAuth, getRolEfectivo, logout } = useAuth()
  const [vista, setVista] = useState("login")
  const [mascotaSeleccionada, setMascotaSeleccionada] = useState(null)
  const [mascotas, setMascotas] = useState([])
  const [loadingMascotas, setLoadingMascotas] = useState(false)
  const [mostrarLogin, setMostrarLogin] = useState(true)

  useEffect(() => {
    if (usuarioAuth) {
      setVista("dashboard")
      cargarMascotas(usuarioAuth.id, usuarioAuth.rol)
    }
  }, [usuarioAuth])

  const cargarMascotas = async (userId, userRol = "dueno") => {
    setLoadingMascotas(true)
    try {
      const rolAUsar = getRolEfectivo ? getRolEfectivo() : userRol
      const resultado = await getMascotasByUser(userId, rolAUsar)
      if (resultado.success) {
        setMascotas(resultado.data)
      }
    } catch (err) {
      console.error("[App] Error al cargar mascotas:", err)
    } finally {
      setLoadingMascotas(false)
    }
  }

  const handleLoginSuccess = (usuarioData) => {
    setVista("dashboard")
    cargarMascotas(usuarioData.id, usuarioData.rol)
    setMostrarLogin(true)
  }

  const handleRegisterSuccess = (usuarioData) => {
    setVista("dashboard")
    cargarMascotas(usuarioData.id, usuarioData.rol)
    setMostrarLogin(true)
  }

  const handleLogout = async () => {
    await logout()
    setMascotas([])
    setMascotaSeleccionada(null)
    setVista("login")
  }

  const handleSelectMascota = (mascota) => {
    setMascotaSeleccionada(mascota)
    setVista("detalle")
  }

  const handleVolver = () => {
    setMascotaSeleccionada(null)
    setVista("dashboard")
  }

  const handleMascotaCreada = (nuevaMascota) => {
    setMascotas((prevMascotas) => [nuevaMascota, ...prevMascotas])
  }

  const handleMascotaAnadida = (mascotaAnadida) => {
    const yaExiste = mascotas.some((m) => m.id === mascotaAnadida.id)
    if (!yaExiste) {
      setMascotas((prevMascotas) => [mascotaAnadida, ...prevMascotas])
    }
  }

  const usuario = usuarioAuth

  if (!usuario) {
    return mostrarLogin ? (
      <Login onLoginSuccess={handleLoginSuccess} onToggleRegister={() => setMostrarLogin(false)} />
    ) : (
      <Register onRegisterSuccess={handleRegisterSuccess} onToggleLogin={() => setMostrarLogin(true)} />
    )
  }

  if (loadingMascotas) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white flex items-center justify-center">
        <div className="text-center text-blue-800">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="font-medium">Cargando mascotas...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {vista === "dashboard" ? (
        <Dashboard
          mascotas={mascotas}
          onSelectMascota={handleSelectMascota}
          nombreUsuario={usuario.nombre}
          usuarioId={usuario.id}
          usuarioRol={usuario.rol}
          onLogout={handleLogout}
          onMascotaCreada={handleMascotaCreada}
          onMascotaAnadida={handleMascotaAnadida}
        />
      ) : vista === "detalle" ? (
        <DetallesMascota mascota={mascotaSeleccionada} onVolver={handleVolver} usuarioId={usuario.id} />
      ) : null}
    </div>
  )
}
