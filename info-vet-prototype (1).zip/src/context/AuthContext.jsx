"use client"

/**
 * AuthContext.jsx - Contexto de Autenticacion
 * Gestiona estado global del usuario autenticado
 * SOLO llama funciones de services/api.js - NUNCA Firebase directamente
 */

import { createContext, useState, useEffect, useContext } from "react"
import { login as apiLogin, register as apiRegister, logout as apiLogout } from "../services/api"

export const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [usuario, setUsuario] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [modoProfesional, setModoProfesional] = useState(false)

  useEffect(() => {
    const usuarioGuardado = localStorage.getItem("infovet_usuario")
    if (usuarioGuardado) {
      try {
        setUsuario(JSON.parse(usuarioGuardado))
      } catch (err) {
        console.error("[Auth] Error al restaurar usuario:", err)
        localStorage.removeItem("infovet_usuario")
      }
    }
    setLoading(false)
  }, [])

  const login = async (email, password) => {
    try {
      setLoading(true)
      setError(null)

      const resultado = await apiLogin(email, password)

      if (!resultado.success) {
        throw new Error(resultado.error)
      }

      setUsuario(resultado.data)
      localStorage.setItem("infovet_usuario", JSON.stringify(resultado.data))

      return { success: true, data: resultado.data }
    } catch (err) {
      const mensaje = err.message || "Error en login"
      setError(mensaje)
      return { success: false, error: mensaje }
    } finally {
      setLoading(false)
    }
  }

  const register = async (nombre, email, password, telefono = "", direccion = "") => {
    try {
      setLoading(true)
      setError(null)

      if (!nombre || !email || !password) {
        throw new Error("Todos los campos son requeridos")
      }

      if (password.length < 6) {
        throw new Error("La contrasena debe tener al menos 6 caracteres")
      }

      const resultado = await apiRegister(nombre, email, password, telefono, direccion)

      if (!resultado.success) {
        throw new Error(resultado.error)
      }

      setUsuario(resultado.data)
      localStorage.setItem("infovet_usuario", JSON.stringify(resultado.data))

      return { success: true, data: resultado.data }
    } catch (err) {
      const mensaje = err.message || "Error en registro"
      setError(mensaje)
      return { success: false, error: mensaje }
    } finally {
      setLoading(false)
    }
  }

  const logout = async () => {
    try {
      await apiLogout()
      setUsuario(null)
      setError(null)
      setModoProfesional(false)
      localStorage.removeItem("infovet_usuario")
      return { success: true }
    } catch (err) {
      console.error("[Auth] Error en logout:", err)
      return { success: false, error: "Error al cerrar sesion" }
    }
  }

  const toggleModoProfesional = () => {
    if (usuario?.rol === "veterinario") {
      setModoProfesional((prev) => !prev)
    }
  }

  const getRolEfectivo = () => {
    if (usuario?.rol === "veterinario" && modoProfesional) {
      return "veterinario"
    }
    if (usuario?.rol === "veterinario" && !modoProfesional) {
      return "dueno"
    }
    return usuario?.rol || "dueno"
  }

  return (
    <AuthContext.Provider
      value={{
        usuario,
        loading,
        error,
        login,
        register,
        logout,
        modoProfesional,
        toggleModoProfesional,
        getRolEfectivo,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth debe usarse dentro de AuthProvider")
  }
  return context
}
