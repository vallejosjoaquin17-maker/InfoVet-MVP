"use client"

/**
 * Dashboard.jsx - Vista Principal de Companeros
 * Cambio de terminologia: mascota -> companero
 * Agregado prop onCompaneroAnadido
 */

import { useState } from "react"
import { Plus, Stethoscope, User } from "lucide-react"
import TarjetaMascota from "./TarjetaMascota"
import AgregarMascotaModal from "./AgregarMascotaModal"
import Header from "./Header"
import { useAuth } from "../context/AuthContext"

export default function Dashboard({
  mascotas,
  onSelectMascota,
  nombreUsuario,
  usuarioId,
  onLogout,
  onMascotaCreada,
  onCompaneroAnadido,
}) {
  const [mostrarModal, setMostrarModal] = useState(false)
  const { usuario, modoProfesional, toggleModoProfesional } = useAuth()

  const handleMascotaCreada = (mascota) => {
    onMascotaCreada(mascota)
  }

  const handleVerDetalle = (mascota) => {
    // Implementación para ver detalles de la mascota
  }

  const handleCompaneroAnadido = (companero) => {
    onCompaneroAnadido(companero)
  }

  return (
    <div className="min-h-screen pb-8">
      <Header nombreUsuario={nombreUsuario} onLogout={onLogout} />

      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="flex-1">
            <h2 className="text-2xl font-bold text-gray-800 mb-2">
              {usuario?.rol === "veterinario" ? (modoProfesional ? "Mis Pacientes" : "Mis Companeros") : ""}
            </h2>
            <p className="text-gray-600">
              {usuario?.rol === "veterinario" && modoProfesional
                ? "Gestion profesional de historiales clinicos"
                : "Gestiona el historial medico de tus companeros"}
            </p>
          </div>

          <div className="flex gap-2 items-center">
            {usuario?.rol === "veterinario" && (
              <div className="flex items-center gap-2 bg-white rounded-lg px-4 py-2 shadow-sm border border-gray-200">
                <User className={`w-5 h-5 ${!modoProfesional ? "text-indigo-600" : "text-gray-400"}`} />
                <button
                  onClick={toggleModoProfesional}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    modoProfesional ? "bg-green-600" : "bg-gray-300"
                  }`}
                  aria-label="Alternar modo profesional"
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      modoProfesional ? "translate-x-6" : "translate-x-1"
                    }`}
                  />
                </button>
                <Stethoscope className={`w-5 h-5 ${modoProfesional ? "text-green-600" : "text-gray-400"}`} />
                <span className="text-sm font-medium text-gray-700">
                  {modoProfesional ? "Modo Profesional" : "Modo Personal"}
                </span>
              </div>
            )}

            <button
              onClick={() => setMostrarModal(true)}
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors font-medium"
            >
              <Plus className="w-5 h-5" />
              <span>Agregar Companero</span>
            </button>
          </div>
        </div>

        {mascotas && mascotas.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mascotas.map((mascota) => (
              <TarjetaMascota key={mascota.id} mascota={mascota} onClick={() => onSelectMascota(mascota)} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-gray-50 rounded-xl border-2 border-dashed border-gray-300">
            <p className="text-gray-600 text-lg mb-4">No hay companeros registrados</p>
            <p className="text-gray-500 mb-6">
              Agrega tu primer companero para comenzar a gestionar su historial medico
            </p>
            <button
              onClick={() => setMostrarModal(true)}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg flex items-center gap-2 transition-colors font-medium mx-auto"
            >
              <Plus className="w-5 h-5" />
              Agregar Primer Companero
            </button>
          </div>
        )}
      </main>

      {/* Modal Agregar Companero */}
      {mostrarModal && (
        <AgregarMascotaModal
          onClose={() => setMostrarModal(false)}
          onMascotaCreada={handleMascotaCreada}
          onVerDetalle={handleVerDetalle}
          onCompaneroAnadido={handleCompaneroAnadido}
          usuarioId={usuarioId}
        />
      )}
    </div>
  )
}
