"use client"

import { useState } from "react"
import { Loader2, User, Stethoscope, Building2, Mail, ArrowLeft } from "lucide-react"

export default function Login({ onLoginSuccess, onToggleRegister }) {
  const [rolSeleccionado, setRolSeleccionado] = useState(null)
  const [identificador, setIdentificador] = useState("")
  const [contraseña, setContraseña] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const [esperandoCodigo, setEsperandoCodigo] = useState(false)
  const [codigoVerificacion, setCodigoVerificacion] = useState("")
  const [codigoEnviado, setCodigoEnviado] = useState("")
  const [usuarioPendiente, setUsuarioPendiente] = useState(null)
  const [correoDestino, setCorreoDestino] = useState("")

  const handleLogin = async (e) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      const { loginPaso1 } = await import("../services/api")
      const resultado = await loginPaso1(identificador, contraseña)

      if (resultado.success) {
        if (resultado.data.rol !== rolSeleccionado) {
          setError(`Esta cuenta pertenece a un ${resultado.data.rol}, no a ${rolSeleccionado}`)
          setLoading(false)
          return
        }

        setUsuarioPendiente(resultado.data)
        setCodigoEnviado(resultado.codigoVerificacion)
        setCorreoDestino(resultado.data.email)
        setEsperandoCodigo(true)
      } else {
        setError(resultado.error || "Error al iniciar sesión")
      }
    } catch (err) {
      setError("Error en la conexión")
      console.error("[Login] Error:", err)
    } finally {
      setLoading(false)
    }
  }

  const handleVerificarCodigo = async (e) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      if (codigoVerificacion.trim() !== codigoEnviado) {
        setError("Código de verificación incorrecto")
        setLoading(false)
        return
      }

      // Codigo correcto, completar login
      onLoginSuccess(usuarioPendiente)
    } catch (err) {
      setError("Error al verificar el código")
      console.error("[Login] Error verificacion:", err)
    } finally {
      setLoading(false)
    }
  }

  const handleVolverLogin = () => {
    setEsperandoCodigo(false)
    setCodigoVerificacion("")
    setUsuarioPendiente(null)
    setCodigoEnviado("")
    setError("")
  }

  if (esperandoCodigo) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md border border-blue-100">
          <button
            onClick={handleVolverLogin}
            className="text-blue-600 hover:text-blue-700 mb-4 flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Volver al inicio de sesión
          </button>

          <div className="text-center mb-8">
            <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
              <Mail className="w-8 h-8 text-blue-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-800 mb-2">Código de Verificación</h1>
            <p className="text-gray-600 text-sm">
              Hemos enviado un código de 6 dígitos a<br />
              <span className="font-semibold text-gray-800">{correoDestino}</span>
            </p>
          </div>

          <form onSubmit={handleVerificarCodigo} className="space-y-5">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">{error}</div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Código de Verificación</label>
              <input
                type="text"
                value={codigoVerificacion}
                onChange={(e) => setCodigoVerificacion(e.target.value)}
                placeholder="123456"
                maxLength={6}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 text-center text-2xl tracking-widest font-mono"
              />
            </div>

            <button
              type="submit"
              disabled={loading || codigoVerificacion.length !== 6}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white font-bold py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : null}
              {loading ? "Verificando..." : "Verificar Código"}
            </button>

            <div className="text-center">
              <p className="text-xs text-gray-500 mt-2">
                Demo: El código es <span className="font-mono font-bold">{codigoEnviado}</span>
              </p>
              <button
                type="button"
                className="text-blue-600 hover:text-blue-700 text-sm mt-3"
                onClick={() => {
                  setError("")
                  alert(`Código reenviado a ${correoDestino}`)
                }}
              >
                Reenviar código
              </button>
            </div>
          </form>
        </div>
      </div>
    )
  }

  if (!rolSeleccionado) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-2xl border border-blue-100">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-bold text-gray-800 mb-2">Acceso a InfoVet</h1>
            <p className="text-gray-600">Plataforma Clínica Veterinaria</p>
          </div>

          <div className="space-y-4">
            <button
              onClick={() => setRolSeleccionado("dueno")}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white p-6 rounded-xl transition-all transform hover:scale-[1.02] shadow-lg"
            >
              <div className="flex items-center justify-center gap-4">
                <User className="w-8 h-8" />
                <div className="text-left">
                  <div className="text-xl font-bold">Dueño de Mascota</div>
                  <div className="text-sm text-blue-100">Acceso rápido al historial de tu mascota</div>
                </div>
              </div>
            </button>

            <div className="grid md:grid-cols-2 gap-4">
              <button
                onClick={() => setRolSeleccionado("veterinario")}
                className="bg-green-50 hover:bg-green-100 text-green-800 p-5 rounded-xl transition-all border-2 border-green-200"
              >
                <div className="flex flex-col items-center gap-2">
                  <Stethoscope className="w-7 h-7" />
                  <div className="font-semibold">Médico Veterinario</div>
                </div>
              </button>

              <button
                onClick={() => setRolSeleccionado("fundacion")}
                className="bg-purple-50 hover:bg-purple-100 text-purple-800 p-5 rounded-xl transition-all border-2 border-purple-200"
              >
                <div className="flex flex-col items-center gap-2">
                  <Building2 className="w-7 h-7" />
                  <div className="font-semibold">Fundación</div>
                </div>
              </button>
            </div>
          </div>

          <div className="mt-8 text-center">
            <p className="text-gray-600 text-sm">
              ¿No tienes cuenta?{" "}
              <button onClick={onToggleRegister} className="text-blue-600 hover:text-blue-700 font-semibold">
                Regístrate aquí
              </button>
            </p>
          </div>
        </div>
      </div>
    )
  }

  const getRolNombre = () => {
    if (rolSeleccionado === "dueno") return "Dueño"
    if (rolSeleccionado === "veterinario") return "Veterinario"
    return "Fundación"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md border border-blue-100">
        <button onClick={() => setRolSeleccionado(null)} className="text-blue-600 hover:text-blue-700 mb-4">
          ← Volver a selección de rol
        </button>

        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">InfoVet</h1>
          <p className="text-gray-600">Ingreso como {getRolNombre()}</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-5">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">{error}</div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Correo Electrónico o Usuario</label>
            <input
              type="text"
              value={identificador}
              onChange={(e) => setIdentificador(e.target.value)}
              placeholder="tu@email.com o @usuario"
              required
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Contraseña</label>
            <input
              type="password"
              value={contraseña}
              onChange={(e) => setContraseña(e.target.value)}
              placeholder="••••••••"
              required
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white font-bold py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : null}
            {loading ? "Verificando..." : "Continuar"}
          </button>
        </form>

        {rolSeleccionado === "dueno" && (
          <div className="mt-4 p-3 bg-blue-50 rounded-lg">
            <p className="text-xs text-gray-600 mb-1">
              <strong>Demo Dueño:</strong>
            </p>
            <p className="text-xs text-gray-500">
              juan@example.com / password123
              <br />o @juanperez / password123
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
