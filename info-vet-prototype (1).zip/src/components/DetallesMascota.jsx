"use client"

/**
 * DetallesMascota.jsx - Vista Detallada de Ficha Medica
 * Cambio de terminologia: mascota -> companero
 */

import { useState, useEffect } from "react"
import {
  ArrowLeft,
  Heart,
  Calendar,
  Syringe,
  Stethoscope,
  Scissors,
  Download,
  Loader2,
  User,
  MapPin,
  Phone,
  Plus,
  Clock,
  Lock,
  CheckCircle,
  AlertCircle,
  Edit2,
  Save,
} from "lucide-react"
import DatoVital from "./atomic/DatoVital"
import PerfilDueno from "./PerfilDueno"
import FormularioProcedimiento from "./FormularioProcedimiento"
import { descargarFichaPorChip, getHistorialByMascotaDocId, updateCompanero, verificarChip } from "../services/api"
import { useAuth } from "../context/AuthContext"
import { tienePermiso } from "../config/roles"

export default function DetallesMascota({ mascota, onVolver, usuarioId }) {
  const [descargando, setDescargando] = useState(false)
  const [errorDescarga, setErrorDescarga] = useState("")
  const [mostrarPerfilDueno, setMostrarPerfilDueno] = useState(false)
  const [mostrarFormProcedimiento, setMostrarFormProcedimiento] = useState(false)
  const [historial, setHistorial] = useState(mascota?.historialMedico || [])
  const [cargandoHistorial, setCargandoHistorial] = useState(false)

  const { usuario, getRolEfectivo } = useAuth()
  const [modoEdicion, setModoEdicion] = useState(false)
  const [datosClinicosEdit, setDatosClinicosEdit] = useState({})
  const [guardando, setGuardando] = useState(false)
  const [verificandoChip, setVerificandoChip] = useState(false)
  const [mensajeExito, setMensajeExito] = useState("")

  const rolEfectivo = getRolEfectivo()
  const esVeterinarioPro = usuario?.rol === "veterinario" && rolEfectivo === "veterinario"
  const puedeEditarClinica = tienePermiso(rolEfectivo, "EDITAR_INFO_CLINICA")
  const puedeVerificarChip = tienePermiso(rolEfectivo, "VERIFICAR_CHIP")

  useEffect(() => {
    if (mascota?.historialMedico) {
      setHistorial(mascota.historialMedico)
    }
    if (mascota?.infoClinica) {
      setDatosClinicosEdit(mascota.infoClinica)
    }
  }, [mascota])

  if (!mascota) return null

  const iconoPorTipo = {
    Vacuna: {
      icon: Syringe,
      color: "text-green-600",
      bg: "bg-green-100",
      border: "border-l-4 border-green-600",
    },
    Consulta: {
      icon: Stethoscope,
      color: "text-blue-600",
      bg: "bg-blue-100",
      border: "border-l-4 border-blue-600",
    },
    Cirugia: {
      icon: Scissors,
      color: "text-red-600",
      bg: "bg-red-100",
      border: "border-l-4 border-red-600",
    },
  }

  const historialOrdenado = [...historial].sort((a, b) => {
    const fechaA = new Date(a.fecha + " " + (a.hora || "00:00"))
    const fechaB = new Date(b.fecha + " " + (b.hora || "00:00"))
    return fechaB - fechaA
  })

  const handleDescargar = async () => {
    setErrorDescarga("")
    setDescargando(true)

    try {
      const resultado = await descargarFichaPorChip(mascota.chip)
      if (!resultado.success) {
        setErrorDescarga(resultado.error || "Error al descargar")
      }
    } catch (err) {
      setErrorDescarga("Error en la descarga")
    } finally {
      setDescargando(false)
    }
  }

  const handleProcedimientoCreado = async (nuevoProcedimiento) => {
    setMostrarFormProcedimiento(false)
    setCargandoHistorial(true)
    try {
      const res = await getHistorialByMascotaDocId(mascota.id)
      if (res.success) {
        setHistorial(res.data)
      }
    } catch (err) {
      console.error("Error recargando historial:", err)
    } finally {
      setCargandoHistorial(false)
    }
  }

  const handleGuardarClinica = async () => {
    setGuardando(true)
    setMensajeExito("")
    try {
      const resultado = await updateCompanero(mascota.id, datosClinicosEdit, rolEfectivo, usuarioId)
      if (resultado.success) {
        setMensajeExito("Datos clinicos actualizados correctamente")
        setModoEdicion(false)
        setTimeout(() => setMensajeExito(""), 3000)
      } else {
        setErrorDescarga(resultado.error || "Error al guardar")
      }
    } catch (err) {
      setErrorDescarga("Error al guardar datos clinicos")
    } finally {
      setGuardando(false)
    }
  }

  const handleVerificarChip = async () => {
    if (!mascota.chip || !esVeterinarioPro) return

    setVerificandoChip(true)
    setMensajeExito("")
    try {
      const resultado = await verificarChip(mascota.id, mascota.chip, usuarioId)
      if (resultado.success) {
        setMensajeExito("Chip verificado exitosamente")
        mascota.chipVerificado = true
        mascota.verificadoPor = usuarioId
        setTimeout(() => setMensajeExito(""), 3000)
      } else {
        setErrorDescarga(resultado.error || "Error al verificar chip")
      }
    } catch (err) {
      setErrorDescarga("Error al verificar chip")
    } finally {
      setVerificandoChip(false)
    }
  }

  return (
    <div className="min-h-screen pb-8">
      {/* Header */}
      <header className="bg-gradient-to-r from-indigo-600 to-blue-500 text-white py-6 px-4 shadow-lg">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={onVolver}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              aria-label="Volver"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <span>{mascota.especie === "Perro" ? "🐕" : "🐱"}</span>
              {mascota.nombre}
            </h1>
          </div>

          <button
            onClick={handleDescargar}
            disabled={descargando}
            className="bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors font-medium"
          >
            {descargando ? <Loader2 className="w-5 h-5 animate-spin" /> : <Download className="w-5 h-5" />}
            {descargando ? "Descargando..." : "Descargar Ficha"}
          </button>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-8">
        {errorDescarga && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">{errorDescarga}</div>
        )}

        {mensajeExito && (
          <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6 flex items-center gap-2">
            <CheckCircle className="w-5 h-5" />
            {mensajeExito}
          </div>
        )}

        {!puedeEditarClinica && (
          <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 px-4 py-3 rounded-lg mb-6 flex items-center gap-2">
            <Lock className="w-5 h-5" />
            <span>
              Solo puedes editar datos basicos (nombre, foto, direccion). Los datos clinicos son de solo lectura.
            </span>
          </div>
        )}

        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="md:col-span-1">
              <img
                src={mascota.foto || "/placeholder.svg?height=256&width=256&query=pet"}
                alt={mascota.nombre}
                className="w-full h-64 object-cover rounded-lg shadow-md"
              />
            </div>

            <div className="md:col-span-2">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
                  <Heart className="w-6 h-6 text-red-500" />
                  Datos del Companero
                </h2>

                {puedeEditarClinica && !modoEdicion && (
                  <button
                    onClick={() => setModoEdicion(true)}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors font-medium text-sm"
                  >
                    <Edit2 className="w-4 h-4" />
                    Editar Datos Clinicos
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <DatoVital label="Especie" valor={mascota.infoClinica?.especie || mascota.especie} />

                {/* Raza - editable solo para veterinarios */}
                {modoEdicion && puedeEditarClinica ? (
                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-1">Raza</label>
                    <input
                      type="text"
                      value={datosClinicosEdit.raza || ""}
                      onChange={(e) => setDatosClinicosEdit({ ...datosClinicosEdit, raza: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>
                ) : (
                  <div className={!puedeEditarClinica ? "relative" : ""}>
                    <DatoVital label="Raza" valor={mascota.infoClinica?.raza || mascota.raza} />
                    {!puedeEditarClinica && <Lock className="absolute top-2 right-2 w-4 h-4 text-gray-400" />}
                  </div>
                )}

                {/* Edad - editable solo para veterinarios */}
                {modoEdicion && puedeEditarClinica ? (
                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-1">Edad (años)</label>
                    <input
                      type="number"
                      value={datosClinicosEdit.edad || ""}
                      onChange={(e) =>
                        setDatosClinicosEdit({ ...datosClinicosEdit, edad: Number.parseInt(e.target.value) })
                      }
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>
                ) : (
                  <div className={!puedeEditarClinica ? "relative" : ""}>
                    <DatoVital label="Edad" valor={`${mascota.infoClinica?.edad || mascota.edad} años`} />
                    {!puedeEditarClinica && <Lock className="absolute top-2 right-2 w-4 h-4 text-gray-400" />}
                  </div>
                )}

                {/* Peso - editable solo para veterinarios */}
                {modoEdicion && puedeEditarClinica ? (
                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-1">Peso (kg)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={datosClinicosEdit.peso || ""}
                      onChange={(e) =>
                        setDatosClinicosEdit({ ...datosClinicosEdit, peso: Number.parseFloat(e.target.value) })
                      }
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>
                ) : (
                  <div className={!puedeEditarClinica ? "relative" : ""}>
                    <DatoVital label="Peso" valor={`${mascota.infoClinica?.peso || mascota.peso} kg`} />
                    {!puedeEditarClinica && <Lock className="absolute top-2 right-2 w-4 h-4 text-gray-400" />}
                  </div>
                )}

                <DatoVital label="Sexo" valor={mascota.infoClinica?.sexo || mascota.sexo} />

                <div className="col-span-2">
                  <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-sm font-medium text-gray-600">Chip</label>
                      {mascota.chipVerificado ? (
                        <div className="flex items-center gap-1 text-green-600 text-sm">
                          <CheckCircle className="w-4 h-4" />
                          <span>Verificado</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1 text-yellow-600 text-sm">
                          <AlertCircle className="w-4 h-4" />
                          <span>No verificado</span>
                        </div>
                      )}
                    </div>
                    <p className="text-gray-800 font-mono">{mascota.chip}</p>

                    {/* Boton verificar solo para veterinarios en modo profesional */}
                    {puedeVerificarChip && !mascota.chipVerificado && (
                      <button
                        onClick={handleVerificarChip}
                        disabled={verificandoChip}
                        className="mt-3 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors font-medium text-sm w-full justify-center"
                      >
                        {verificandoChip ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <CheckCircle className="w-4 h-4" />
                        )}
                        {verificandoChip ? "Verificando..." : "Validar Chip"}
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {modoEdicion && puedeEditarClinica && (
                <div className="flex gap-3 mt-6">
                  <button
                    onClick={handleGuardarClinica}
                    disabled={guardando}
                    className="flex-1 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white px-4 py-2 rounded-lg flex items-center justify-center gap-2 transition-colors font-medium"
                  >
                    {guardando ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                    {guardando ? "Guardando..." : "Guardar Cambios"}
                  </button>
                  <button
                    onClick={() => {
                      setModoEdicion(false)
                      setDatosClinicosEdit(mascota.infoClinica || {})
                    }}
                    className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-lg font-medium transition-colors"
                  >
                    Cancelar
                  </button>
                </div>
              )}

              {mascota.idInterno && (
                <div className="mt-4 p-3 bg-indigo-50 rounded-lg">
                  <p className="text-sm text-indigo-600">
                    <strong>ID Sistema (UUID):</strong> <span className="font-mono">{mascota.idInterno}</span>
                  </p>
                </div>
              )}

              <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3">
                {mascota.direccion && (
                  <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg">
                    <MapPin className="w-4 h-4 text-gray-500" />
                    <div>
                      <p className="text-xs text-gray-500">Direccion</p>
                      <p className="text-sm text-gray-800">{mascota.direccion}</p>
                    </div>
                  </div>
                )}
                {mascota.telefonoContacto && (
                  <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg">
                    <Phone className="w-4 h-4 text-gray-500" />
                    <div>
                      <p className="text-xs text-gray-500">Telefono Contacto</p>
                      <p className="text-sm text-gray-800">{mascota.telefonoContacto}</p>
                    </div>
                  </div>
                )}
              </div>

              <div className="mt-4">
                <button
                  onClick={() => setMostrarPerfilDueno(true)}
                  className="flex items-center gap-3 p-3 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors w-full text-left"
                >
                  <div className="w-10 h-10 bg-blue-200 rounded-full flex items-center justify-center">
                    <User className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-xs text-blue-600">Dueno Asociado (Click para ver perfil)</p>
                    <p className="font-medium text-gray-800">{mascota.dueno?.nombre || "Ver perfil del dueno"}</p>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
              <Calendar className="w-6 h-6 text-indigo-600" />
              Historial Clinico
            </h2>
            {tienePermiso(rolEfectivo, "AGREGAR_PROCEDIMIENTOS") && (
              <button
                onClick={() => setMostrarFormProcedimiento(true)}
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors font-medium"
              >
                <Plus className="w-5 h-5" />
                Agregar Procedimiento
              </button>
            )}
          </div>

          {cargandoHistorial ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 text-indigo-600 animate-spin" />
              <span className="ml-2 text-gray-500">Actualizando historial...</span>
            </div>
          ) : historialOrdenado.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No hay registros medicos</p>
          ) : (
            <div className="space-y-4">
              {historialOrdenado.map((registro) => {
                const config = iconoPorTipo[registro.tipo] || iconoPorTipo["Consulta"]
                const IconComponent = config.icon

                return (
                  <div key={registro.id} className={`p-5 rounded-lg ${config.bg} ${config.border}`}>
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0 mt-1">
                        <IconComponent className={`w-5 h-5 ${config.color}`} />
                      </div>

                      <div className="flex-grow">
                        <div className="mb-2">
                          <h3 className="font-bold text-gray-800 text-lg">{registro.procedimiento || registro.tipo}</h3>
                          <div className="flex items-center gap-2 text-sm text-gray-700">
                            <Calendar className="w-4 h-4" />
                            {new Date(registro.fecha).toLocaleDateString("es-CL", {
                              year: "numeric",
                              month: "long",
                              day: "numeric",
                            })}
                            {registro.hora && (
                              <>
                                <Clock className="w-4 h-4 ml-2" />
                                {registro.hora}
                              </>
                            )}
                          </div>
                        </div>
                        <p className="text-gray-700 mb-3">{registro.descripcion}</p>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                          <p className="text-gray-700">
                            <span className="font-semibold">Medico:</span> {registro.medico || registro.veterinario}
                          </p>
                          <p className="text-gray-700">
                            <span className="font-semibold">Clinica:</span> {registro.clinica}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>

        <button
          onClick={onVolver}
          className="fixed bottom-8 right-8 bg-indigo-600 hover:bg-indigo-700 text-white p-4 rounded-full shadow-lg transition-all duration-300 hover:scale-110 md:hidden"
          aria-label="Volver"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
      </main>

      {mostrarPerfilDueno && (
        <PerfilDueno
          duenioId={mascota.duenioId}
          mascotaDireccion={mascota.direccion}
          mascotaTelefono={mascota.telefonoContacto}
          mascotaNombre={mascota.nombre}
          onClose={() => setMostrarPerfilDueno(false)}
        />
      )}

      {mostrarFormProcedimiento && (
        <FormularioProcedimiento
          mascotaId={mascota.id}
          mascotaNombre={mascota.nombre}
          onClose={() => setMostrarFormProcedimiento(false)}
          onProcedimientoCreado={handleProcedimientoCreado}
        />
      )}
    </div>
  )
}
