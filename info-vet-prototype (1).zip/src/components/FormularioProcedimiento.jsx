"use client"

/**
 * FormularioProcedimiento.jsx - Formulario para agregar nuevo procedimiento
 * Nuevo componente para registrar procedimientos medicos
 */

import { useState } from "react"
import { X, Loader2, AlertCircle, CheckCircle, Calendar, Clock, Stethoscope, Building, FileText } from "lucide-react"
import { crearProcedimiento } from "../services/api"

export default function FormularioProcedimiento({ mascotaId, mascotaNombre, onClose, onProcedimientoCreado }) {
  const [formData, setFormData] = useState({
    procedimiento: "",
    descripcion: "",
    medico: "",
    clinica: "",
    fecha: new Date().toISOString().split("T")[0],
    hora: new Date().toTimeString().slice(0, 5),
  })

  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError("")

    if (!formData.procedimiento.trim()) {
      setError("El nombre del procedimiento es obligatorio")
      return
    }
    if (!formData.descripcion.trim()) {
      setError("La descripcion es obligatoria")
      return
    }
    if (!formData.medico.trim()) {
      setError("El nombre del medico es obligatorio")
      return
    }
    if (!formData.clinica.trim()) {
      setError("El nombre de la clinica es obligatorio")
      return
    }
    if (!formData.fecha) {
      setError("La fecha es obligatoria")
      return
    }
    if (!formData.hora) {
      setError("La hora es obligatoria")
      return
    }

    setLoading(true)

    try {
      const res = await crearProcedimiento({
        mascotaDocId: mascotaId,
        ...formData,
      })

      if (res.success) {
        setSuccess(true)
        setTimeout(() => {
          onProcedimientoCreado(res.data)
        }, 1500)
      } else {
        setError(res.error || "Error al registrar procedimiento")
      }
    } catch (err) {
      setError("Error al registrar procedimiento")
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-xl shadow-2xl w-full max-w-md p-8 text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <h3 className="text-xl font-bold text-gray-800 mb-2">Procedimiento Registrado</h3>
          <p className="text-gray-600">El registro ha sido guardado correctamente</p>
        </div>
      </div>
    )
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="bg-gradient-to-r from-green-600 to-emerald-500 text-white p-6 sticky top-0">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold">Agregar Procedimiento</h2>
              <p className="text-green-100 text-sm">Para: {mascotaNombre}</p>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-white/20 rounded-lg transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg flex items-center gap-2">
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              {error}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Stethoscope className="w-4 h-4 inline mr-1" />
              Procedimiento <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              name="procedimiento"
              value={formData.procedimiento}
              onChange={handleInputChange}
              placeholder="Ej: Vacuna Antirrabica, Consulta General, Cirugia..."
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-gray-800"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <FileText className="w-4 h-4 inline mr-1" />
              Descripcion <span className="text-red-500">*</span>
            </label>
            <textarea
              name="descripcion"
              value={formData.descripcion}
              onChange={handleInputChange}
              placeholder="Describe el procedimiento realizado..."
              rows={3}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-gray-800 resize-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <Calendar className="w-4 h-4 inline mr-1" />
                Fecha <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                name="fecha"
                value={formData.fecha}
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-gray-800"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <Clock className="w-4 h-4 inline mr-1" />
                Hora <span className="text-red-500">*</span>
              </label>
              <input
                type="time"
                name="hora"
                value={formData.hora}
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-gray-800"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Medico Responsable <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              name="medico"
              value={formData.medico}
              onChange={handleInputChange}
              placeholder="Ej: Dr. Carlos Lopez"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-gray-800"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Building className="w-4 h-4 inline mr-1" />
              Clinica <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              name="clinica"
              value={formData.clinica}
              onChange={handleInputChange}
              placeholder="Ej: Clinica Veterinaria San Jose"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-gray-800"
            />
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white py-2 rounded-lg flex items-center justify-center gap-2 font-medium transition-colors"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Guardando...
                </>
              ) : (
                "Guardar Procedimiento"
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
