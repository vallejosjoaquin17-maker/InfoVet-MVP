"use client"

/**
 * PerfilDueno.jsx - Modal con perfil completo del dueno
 * Eliminada direccion del dueno, ahora solo muestra direccion de la mascota
 * Agregado boton "Volver a ficha de la mascota" prominente
 */

import { useState, useEffect } from "react"
import { X, User, Mail, Phone, MapPin, Home, Loader2, ArrowLeft } from "lucide-react"
import { getUsuarioById } from "../services/api"

export default function PerfilDueno({ duenioId, mascotaDireccion, mascotaTelefono, mascotaNombre, onClose }) {
  const [dueno, setDueno] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    const cargarDueno = async () => {
      if (!duenioId) {
        setError("ID de dueno no disponible")
        setLoading(false)
        return
      }

      try {
        const res = await getUsuarioById(duenioId)
        if (res.success) {
          setDueno(res.data)
        } else {
          setError(res.error || "Error al cargar datos del dueno")
        }
      } catch (err) {
        setError("Error al cargar datos del dueno")
      } finally {
        setLoading(false)
      }
    }

    cargarDueno()
  }, [duenioId])

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-600 to-blue-500 text-white p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                <User className="w-6 h-6" />
              </div>
              <h2 className="text-xl font-bold">Perfil del Dueno</h2>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-white/20 rounded-lg transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-8">
              <Loader2 className="w-8 h-8 text-indigo-600 animate-spin mb-4" />
              <p className="text-gray-500">Cargando datos...</p>
            </div>
          ) : error ? (
            <div className="text-center py-8">
              <p className="text-red-600">{error}</p>
            </div>
          ) : dueno ? (
            <div className="space-y-4">
              {/* Datos basicos del dueno - SIN direccion */}
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <User className="w-5 h-5 text-indigo-600" />
                  <div>
                    <p className="text-xs text-gray-500">Nombre</p>
                    <p className="font-medium text-gray-800">{dueno.nombre}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <Mail className="w-5 h-5 text-indigo-600" />
                  <div>
                    <p className="text-xs text-gray-500">Email</p>
                    <p className="font-medium text-gray-800">{dueno.email}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <Phone className="w-5 h-5 text-indigo-600" />
                  <div>
                    <p className="text-xs text-gray-500">Telefono</p>
                    <p className="font-medium text-gray-800">{dueno.telefono || "No registrado"}</p>
                  </div>
                </div>
              </div>

              {(mascotaDireccion || mascotaTelefono) && (
                <div className="border-t pt-4 mt-4">
                  <h3 className="font-semibold text-gray-700 mb-3 flex items-center gap-2">
                    <Home className="w-4 h-4" />
                    Donde vive {mascotaNombre || "la mascota"}
                  </h3>

                  {mascotaDireccion && (
                    <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg mb-2">
                      <MapPin className="w-5 h-5 text-blue-600" />
                      <div>
                        <p className="text-xs text-blue-600">Direccion de la mascota</p>
                        <p className="font-medium text-gray-800">{mascotaDireccion}</p>
                      </div>
                    </div>
                  )}

                  {mascotaTelefono && (
                    <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                      <Phone className="w-5 h-5 text-blue-600" />
                      <div>
                        <p className="text-xs text-blue-600">Telefono de contacto responsable</p>
                        <p className="font-medium text-gray-800">{mascotaTelefono}</p>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : null}
        </div>

        <div className="bg-gray-50 px-6 py-4 space-y-3">
          <button
            onClick={onClose}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
          >
            <ArrowLeft className="w-5 h-5" />
            Volver a ficha de {mascotaNombre || "la mascota"}
          </button>
        </div>
      </div>
    </div>
  )
}
