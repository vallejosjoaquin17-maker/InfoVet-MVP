"use client"

/**
 * TarjetaMascota.jsx - Tarjeta individual de companero para el dashboard
 * Cambio de terminologia en boton: "Ver Ficha Medica"
 */

export default function TarjetaMascota({ mascota, onClick }) {
  if (!mascota) return null

  const emoji = mascota.especie === "Perro" ? "🐕" : "🐱"

  return (
    <div
      onClick={onClick}
      className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer overflow-hidden transform hover:scale-105"
      role="button"
      tabIndex={0}
      aria-label={`Ver detalles de ${mascota.nombre}`}
    >
      {/* Foto */}
      <div className="h-48 overflow-hidden bg-gray-200">
        <img src={mascota.foto || "/placeholder.svg"} alt={mascota.nombre} className="w-full h-full object-cover" />
      </div>

      {/* Contenido */}
      <div className="p-5">
        <div className="flex items-start justify-between mb-3">
          <div>
            <h3 className="text-xl font-bold text-gray-800">{mascota.nombre}</h3>
            <p className="text-sm text-gray-600">{mascota.raza}</p>
          </div>
          <span className="text-2xl">{emoji}</span>
        </div>

        <div className="grid grid-cols-2 gap-3 text-sm mb-3">
          <div className="bg-blue-50 p-2 rounded">
            <p className="text-gray-600">Edad</p>
            <p className="font-semibold text-gray-800">{mascota.edad} anios</p>
          </div>
          <div className="bg-green-50 p-2 rounded">
            <p className="text-gray-600">Peso</p>
            <p className="font-semibold text-gray-800">{mascota.peso} kg</p>
          </div>
        </div>

        <div className="space-y-1 text-xs text-gray-500 mb-3">
          <p>
            <span className="font-medium">Chip:</span> {mascota.chip}
          </p>
          {mascota.idInterno && (
            <p>
              <span className="font-medium">ID:</span> <span className="font-mono">{mascota.idInterno}</span>
            </p>
          )}
        </div>

        <button className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2 rounded-lg font-medium transition-colors">
          Ver Ficha Medica
        </button>
      </div>
    </div>
  )
}
