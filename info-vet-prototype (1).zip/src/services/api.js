/**
 * API Service Layer - UNICO punto de acceso a Firebase
 * Nueva funcion anadirCompaneroAUsuario para vincular companeros buscados
 */

import { signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, onAuthStateChanged } from "firebase/auth"
import {
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  updateDoc,
  query,
  where,
  orderBy,
  serverTimestamp,
  arrayUnion,
} from "firebase/firestore"
import { auth, db } from "../firebase/firebaseConfig"
import { usuariosData, mascotasData, historialesData } from "../data/mockData"
import { filtrarDatosEditables, tienePermiso, ROLES } from "../config/roles"

const USE_MOCK =
  !process.env.NEXT_PUBLIC_FIREBASE_API_KEY || process.env.NEXT_PUBLIC_FIREBASE_API_KEY === "demo-api-key"

/* ================================================================
   UTILIDADES
   ================================================================ */

export function generarUUID() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0
    const v = c === "x" ? r : (r & 0x3) | 0x8
    return v.toString(16)
  })
}

export function generarIdInternoMascota() {
  const year = new Date().getFullYear()
  const uuid = generarUUID().substring(0, 8)
  return `MAS-${year}-${uuid}`
}

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

/* ================================================================
   AUTENTICACION
   ================================================================ */

export async function loginPaso1(identificador, password) {
  try {
    if (USE_MOCK) {
      await delay(500)

      // Buscar por email o username
      const usuario = usuariosData.find(
        (u) => (u.email === identificador || u.username === identificador) && u.password === password,
      )

      if (!usuario) {
        return { success: false, error: "Credenciales invalidas" }
      }

      // Generar codigo de verificacion de 6 digitos
      const codigoVerificacion = Math.floor(100000 + Math.random() * 900000).toString()

      const userData = {
        id: usuario.id,
        nombre: usuario.nombre,
        email: usuario.email,
        telefono: usuario.telefono,
        rol: usuario.rol,
      }

      console.log(`[API] Codigo de verificacion enviado a ${usuario.email}: ${codigoVerificacion}`)

      return {
        success: true,
        data: userData,
        codigoVerificacion,
        mensaje: `Codigo enviado a ${usuario.email}`,
      }
    }

    // Firebase implementation
    const userCredential = await signInWithEmailAndPassword(auth, identificador, password)
    const userDoc = await getDoc(doc(db, "users", userCredential.user.uid))

    if (!userDoc.exists()) {
      return { success: false, error: "Usuario no encontrado en base de datos" }
    }

    const docData = userDoc.data()
    const codigoVerificacion = Math.floor(100000 + Math.random() * 900000).toString()

    const userData = {
      id: userCredential.user.uid,
      nombre: docData.nombre,
      email: docData.email,
      telefono: docData.telefono,
      rol: docData.rol,
    }

    return {
      success: true,
      data: userData,
      codigoVerificacion,
      mensaje: `Codigo enviado a ${userData.email}`,
    }
  } catch (error) {
    console.error("[API] Error en loginPaso1:", error)
    return { success: false, error: error.message || "Error al iniciar sesion" }
  }
}

export async function login(emailOrUsername, password) {
  try {
    if (USE_MOCK) {
      await delay(500)
      const usuario = usuariosData.find(
        (u) => (u.email === emailOrUsername || u.username === emailOrUsername) && u.password === password,
      )
      if (!usuario) {
        return { success: false, error: "Correo/usuario o contrasena invalidos" }
      }
      const userData = {
        id: usuario.id,
        nombre: usuario.nombre,
        email: usuario.email,
        telefono: usuario.telefono,
        rol: usuario.rol,
      }
      return { success: true, data: userData }
    }

    const userCredential = await signInWithEmailAndPassword(auth, emailOrUsername, password)
    const userDoc = await getDoc(doc(db, "users", userCredential.user.uid))

    if (!userDoc.exists()) {
      return { success: false, error: "Usuario no encontrado en base de datos" }
    }

    const docData = userDoc.data()
    const userData = {
      id: userCredential.user.uid,
      nombre: docData.nombre,
      email: docData.email,
      telefono: docData.telefono,
      rol: docData.rol,
    }

    return { success: true, data: userData }
  } catch (error) {
    console.error("[API] Error en login:", error)
    return { success: false, error: error.message || "Error al iniciar sesion" }
  }
}

export async function register(nombre, email, password, telefono = "") {
  try {
    if (USE_MOCK) {
      await delay(800)
      if (usuariosData.some((u) => u.email === email)) {
        return { success: false, error: "El correo ya esta registrado" }
      }
      const nuevoUsuario = {
        id: `user-${Date.now()}`,
        nombre,
        email,
        telefono,
        rol: "dueno",
        createdAt: new Date().toISOString(),
      }
      usuariosData.push({ ...nuevoUsuario, password })
      return { success: true, data: nuevoUsuario }
    }

    const userCredential = await createUserWithEmailAndPassword(auth, email, password)

    const userData = {
      nombre,
      email,
      telefono,
      rol: "dueno",
      createdAt: serverTimestamp(),
    }

    await addDoc(collection(db, "users"), {
      ...userData,
      uid: userCredential.user.uid,
    })

    return {
      success: true,
      data: { id: userCredential.user.uid, ...userData },
    }
  } catch (error) {
    console.error("[API] Error en register:", error)
    return { success: false, error: error.message || "Error al registrarse" }
  }
}

export async function logout() {
  try {
    if (!USE_MOCK) {
      await signOut(auth)
    }
    return { success: true }
  } catch (error) {
    console.error("[API] Error en logout:", error)
    return { success: false, error: "Error al cerrar sesion" }
  }
}

export function onAuthChange(callback) {
  if (USE_MOCK) {
    return () => {}
  }
  return onAuthStateChanged(auth, callback)
}

/* ================================================================
   USUARIOS
   ================================================================ */

export async function getUsuarios() {
  try {
    if (USE_MOCK) {
      await delay(300)
      const usuarios = usuariosData.map((u) => ({
        id: u.id,
        nombre: u.nombre,
        email: u.email,
        telefono: u.telefono,
        rol: u.rol,
      }))
      return { success: true, data: usuarios }
    }

    const querySnapshot = await getDocs(collection(db, "users"))
    const usuarios = querySnapshot.docs.map((doc) => {
      const data = doc.data()
      return {
        id: doc.id,
        nombre: data.nombre,
        email: data.email,
        telefono: data.telefono,
        rol: data.rol,
      }
    })

    return { success: true, data: usuarios }
  } catch (error) {
    console.error("[API] Error al obtener usuarios:", error)
    return { success: false, error: "Error al cargar usuarios", data: [] }
  }
}

export async function getUsuarioById(userId) {
  try {
    if (!userId) {
      return { success: false, error: "ID de usuario requerido" }
    }

    if (USE_MOCK) {
      await delay(200)
      const usuario = usuariosData.find((u) => u.id === userId)
      if (!usuario) {
        return { success: false, error: "Usuario no encontrado" }
      }
      return {
        success: true,
        data: {
          id: usuario.id,
          nombre: usuario.nombre,
          email: usuario.email,
          telefono: usuario.telefono,
          rol: usuario.rol,
        },
      }
    }

    const docSnap = await getDoc(doc(db, "users", userId))
    if (!docSnap.exists()) {
      return { success: false, error: "Usuario no encontrado" }
    }

    const data = docSnap.data()
    return {
      success: true,
      data: {
        id: docSnap.id,
        nombre: data.nombre,
        email: data.email,
        telefono: data.telefono,
        rol: data.rol,
      },
    }
  } catch (error) {
    console.error("[API] Error al obtener usuario:", error)
    return { success: false, error: "Error al cargar usuario" }
  }
}

/* ================================================================
   MASCOTAS / COMPANEROS
   ================================================================ */

export async function getMascotasByUser(userId, userRol = "dueno") {
  try {
    if (!userId) {
      return { success: false, error: "Usuario no autenticado", data: [] }
    }

    if (USE_MOCK) {
      await delay(300)
      let mascotas
      if (userRol === "admin" || userRol === "veterinario") {
        mascotas = mascotasData
      } else {
        mascotas = mascotasData.filter(
          (m) => m.duenioId === userId || (m.dueniosAsociados && m.dueniosAsociados.includes(userId)),
        )
      }

      const mascotasConHistorial = mascotas.map((m) => ({
        ...m,
        historialMedico: historialesData.filter((h) => h.mascotaDocId === m.id || h.mascotaId === m.id),
      }))
      return { success: true, data: mascotasConHistorial }
    }

    let q
    if (userRol === "admin" || userRol === "veterinario") {
      q = query(collection(db, "mascotas"), orderBy("createdAt", "desc"))
    } else {
      // Para Firestore, necesitamos dos queries o array-contains
      q = query(collection(db, "mascotas"), where("duenioId", "==", userId), orderBy("createdAt", "desc"))
    }

    const querySnapshot = await getDocs(q)
    const mascotas = await Promise.all(
      querySnapshot.docs.map(async (docSnap) => {
        const mascotaData = { id: docSnap.id, ...docSnap.data() }

        const historialQuery = query(
          collection(db, "historiales"),
          where("mascotaDocId", "==", docSnap.id),
          orderBy("fecha", "desc"),
        )
        const historialSnapshot = await getDocs(historialQuery)
        mascotaData.historialMedico = historialSnapshot.docs.map((h) => ({
          id: h.id,
          ...h.data(),
        }))

        return mascotaData
      }),
    )

    if (userRol === "dueno") {
      const qAsociados = query(collection(db, "mascotas"), where("dueniosAsociados", "array-contains", userId))
      const asociadosSnapshot = await getDocs(qAsociados)

      for (const docSnap of asociadosSnapshot.docs) {
        if (!mascotas.find((m) => m.id === docSnap.id)) {
          const mascotaData = { id: docSnap.id, ...docSnap.data() }
          const historialQuery = query(
            collection(db, "historiales"),
            where("mascotaDocId", "==", docSnap.id),
            orderBy("fecha", "desc"),
          )
          const historialSnapshot = await getDocs(historialQuery)
          mascotaData.historialMedico = historialSnapshot.docs.map((h) => ({
            id: h.id,
            ...h.data(),
          }))
          mascotas.push(mascotaData)
        }
      }
    }

    return { success: true, data: mascotas }
  } catch (error) {
    console.error("[API] Error al obtener mascotas:", error)
    return { success: false, error: "Error al cargar companeros", data: [] }
  }
}

export async function getMascotaById(mascotaId) {
  try {
    if (USE_MOCK) {
      await delay(200)
      const mascota = mascotasData.find((m) => m.id === mascotaId)
      if (!mascota) {
        return { success: false, error: "Companero no encontrado" }
      }
      return {
        success: true,
        data: {
          ...mascota,
          historialMedico: historialesData.filter((h) => h.mascotaDocId === mascota.id || h.mascotaId === mascota.id),
        },
      }
    }

    const docSnap = await getDoc(doc(db, "mascotas", mascotaId))
    if (!docSnap.exists()) {
      return { success: false, error: "Companero no encontrado" }
    }

    const mascotaData = { id: docSnap.id, ...docSnap.data() }

    const historialQuery = query(
      collection(db, "historiales"),
      where("mascotaDocId", "==", mascotaId),
      orderBy("fecha", "desc"),
    )
    const historialSnapshot = await getDocs(historialQuery)
    mascotaData.historialMedico = historialSnapshot.docs.map((h) => ({
      id: h.id,
      ...h.data(),
    }))

    return { success: true, data: mascotaData }
  } catch (error) {
    console.error("[API] Error al obtener mascota:", error)
    return { success: false, error: "Error al cargar companero" }
  }
}

export async function getMascotaByIdInterno(idInterno) {
  try {
    if (!idInterno || idInterno.trim() === "") {
      return { success: false, error: "ID interno requerido" }
    }

    const idLimpio = idInterno.toUpperCase().trim()

    if (USE_MOCK) {
      await delay(300)
      const mascota = mascotasData.find((m) => m.idInterno && m.idInterno.toUpperCase() === idLimpio)
      if (!mascota) {
        return { success: false, error: "Companero no encontrado", noExiste: true }
      }

      const dueno = usuariosData.find((u) => u.id === mascota.duenioId)
      return {
        success: true,
        data: {
          ...mascota,
          historialMedico: historialesData.filter((h) => h.mascotaDocId === mascota.id || h.mascotaId === mascota.id),
          dueno: dueno
            ? {
                id: dueno.id,
                nombre: dueno.nombre,
                email: dueno.email,
                telefono: dueno.telefono,
              }
            : null,
        },
      }
    }

    const q = query(collection(db, "mascotas"), where("idInterno", "==", idLimpio))
    const querySnapshot = await getDocs(q)

    if (querySnapshot.empty) {
      return { success: false, error: "Companero no encontrado", noExiste: true }
    }

    const mascotaDoc = querySnapshot.docs[0]
    const mascotaData = { id: mascotaDoc.id, ...mascotaDoc.data() }

    if (mascotaData.duenioId) {
      const duenoDoc = await getDoc(doc(db, "users", mascotaData.duenioId))
      if (duenoDoc.exists()) {
        const duenoData = duenoDoc.data()
        mascotaData.dueno = {
          id: duenoDoc.id,
          nombre: duenoData.nombre,
          email: duenoData.email,
          telefono: duenoData.telefono,
        }
      }
    }

    const historialQuery = query(
      collection(db, "historiales"),
      where("mascotaDocId", "==", mascotaDoc.id),
      orderBy("fecha", "desc"),
    )
    const historialSnapshot = await getDocs(historialQuery)
    mascotaData.historialMedico = historialSnapshot.docs.map((h) => ({ id: h.id, ...h.data() }))

    return { success: true, data: mascotaData }
  } catch (error) {
    console.error("[API] Error en busqueda por ID interno:", error)
    return { success: false, error: "Error al buscar companero" }
  }
}

export async function buscarMascotaPorChip(chip) {
  try {
    if (!chip || chip.trim() === "") {
      return { success: false, error: "Ingresa un codigo de chip valido" }
    }

    const chipLimpio = chip.toUpperCase().trim()

    if (USE_MOCK) {
      await delay(400)
      const mascota = mascotasData.find((m) => m.chip.toUpperCase() === chipLimpio)

      if (!mascota) {
        return {
          success: false,
          error: `Chip ${chip} no encontrado en el sistema`,
          noExiste: true,
        }
      }

      const dueno = usuariosData.find((u) => u.id === mascota.duenioId)

      return {
        success: true,
        data: {
          ...mascota,
          historialMedico: historialesData.filter((h) => h.mascotaDocId === mascota.id || h.mascotaId === mascota.id),
          dueno: dueno
            ? {
                id: dueno.id,
                nombre: dueno.nombre,
                email: dueno.email,
                telefono: dueno.telefono,
              }
            : null,
        },
      }
    }

    const q = query(collection(db, "mascotas"), where("chip", "==", chipLimpio))
    const querySnapshot = await getDocs(q)

    if (querySnapshot.empty) {
      return {
        success: false,
        error: `Chip ${chip} no encontrado en el sistema`,
        noExiste: true,
      }
    }

    const mascotaDoc = querySnapshot.docs[0]
    const mascotaData = { id: mascotaDoc.id, ...mascotaDoc.data() }

    const duenoDoc = await getDoc(doc(db, "users", mascotaData.duenioId))
    if (duenoDoc.exists()) {
      const duenoData = duenoDoc.data()
      mascotaData.dueno = {
        id: duenoDoc.id,
        nombre: duenoData.nombre,
        email: duenoData.email,
        telefono: duenoData.telefono,
      }
    }

    const historialQuery = query(
      collection(db, "historiales"),
      where("mascotaDocId", "==", mascotaDoc.id),
      orderBy("fecha", "desc"),
    )
    const historialSnapshot = await getDocs(historialQuery)
    mascotaData.historialMedico = historialSnapshot.docs.map((h) => ({
      id: h.id,
      ...h.data(),
    }))

    return { success: true, data: mascotaData }
  } catch (error) {
    console.error("[API] Error en busqueda por chip:", error)
    return { success: false, error: "Error al buscar por chip" }
  }
}

export async function buscarMascotaPorId(idInterno) {
  return getMascotaByIdInterno(idInterno)
}

export async function validarChipUnico(chip) {
  try {
    if (!chip || chip.trim() === "") {
      return { success: false, error: "Chip invalido" }
    }

    const chipLimpio = chip.toUpperCase().trim()

    if (USE_MOCK) {
      await delay(200)
      const existe = mascotasData.some((m) => m.chip.toUpperCase() === chipLimpio)
      return {
        success: true,
        existe,
        mensaje: existe ? "Este chip ya esta registrado en el sistema" : "Chip disponible",
      }
    }

    const q = query(collection(db, "mascotas"), where("chip", "==", chipLimpio))
    const querySnapshot = await getDocs(q)
    const existe = !querySnapshot.empty

    return {
      success: true,
      existe,
      mensaje: existe ? "Este chip ya esta registrado en el sistema" : "Chip disponible",
    }
  } catch (error) {
    console.error("[API] Error al validar chip:", error)
    return { success: false, error: "Error al validar chip" }
  }
}

export async function verificarCompaneroAsociado(mascotaId, usuarioId) {
  try {
    if (USE_MOCK) {
      await delay(200)
      const mascota = mascotasData.find((m) => m.id === mascotaId)
      if (!mascota) {
        return { success: false, error: "Companero no encontrado" }
      }

      const yaAsociado =
        mascota.duenioId === usuarioId || (mascota.dueniosAsociados && mascota.dueniosAsociados.includes(usuarioId))

      return { success: true, yaAsociado }
    }

    const docSnap = await getDoc(doc(db, "mascotas", mascotaId))
    if (!docSnap.exists()) {
      return { success: false, error: "Companero no encontrado" }
    }

    const mascotaData = docSnap.data()
    const yaAsociado =
      mascotaData.duenioId === usuarioId ||
      (mascotaData.dueniosAsociados && mascotaData.dueniosAsociados.includes(usuarioId))

    return { success: true, yaAsociado }
  } catch (error) {
    console.error("[API] Error al verificar asociacion:", error)
    return { success: false, error: "Error al verificar" }
  }
}

export async function anadirCompaneroAUsuario(usuarioId, mascotaId) {
  try {
    if (!usuarioId || !mascotaId) {
      return { success: false, error: "Usuario y companero son requeridos" }
    }

    // Primero verificar si ya esta asociado
    const verificacion = await verificarCompaneroAsociado(mascotaId, usuarioId)
    if (verificacion.yaAsociado) {
      return {
        success: false,
        error: "Este companero ya esta en tu lista",
        yaExiste: true,
      }
    }

    if (USE_MOCK) {
      await delay(400)
      const mascotaIndex = mascotasData.findIndex((m) => m.id === mascotaId)
      if (mascotaIndex === -1) {
        return { success: false, error: "Companero no encontrado" }
      }

      // Agregar usuario al array de dueniosAsociados
      if (!mascotasData[mascotaIndex].dueniosAsociados) {
        mascotasData[mascotaIndex].dueniosAsociados = []
      }
      mascotasData[mascotaIndex].dueniosAsociados.push(usuarioId)

      // Retornar el companero actualizado con su historial
      const mascotaActualizada = {
        ...mascotasData[mascotaIndex],
        historialMedico: historialesData.filter((h) => h.mascotaDocId === mascotaId || h.mascotaId === mascotaId),
      }

      return {
        success: true,
        data: mascotaActualizada,
        mensaje: `${mascotaActualizada.nombre} ha sido anadido a tus companeros`,
      }
    }

    // Firestore: actualizar documento
    const mascotaRef = doc(db, "mascotas", mascotaId)
    const docSnap = await getDoc(mascotaRef)

    if (!docSnap.exists()) {
      return { success: false, error: "Companero no encontrado" }
    }

    const mascotaData = docSnap.data()
    const dueniosAsociados = mascotaData.dueniosAsociados || []
    dueniosAsociados.push(usuarioId)

    await updateDoc(mascotaRef, { dueniosAsociados })

    // Obtener historial
    const historialQuery = query(
      collection(db, "historiales"),
      where("mascotaDocId", "==", mascotaId),
      orderBy("fecha", "desc"),
    )
    const historialSnapshot = await getDocs(historialQuery)
    const historial = historialSnapshot.docs.map((h) => ({ id: h.id, ...h.data() }))

    return {
      success: true,
      data: {
        id: mascotaId,
        ...mascotaData,
        dueniosAsociados,
        historialMedico: historial,
      },
      mensaje: `${mascotaData.nombre} ha sido anadido a tus companeros`,
    }
  } catch (error) {
    console.error("[API] Error al anadir companero:", error)
    return { success: false, error: "Error al anadir companero" }
  }
}

export async function crearMascota(dataMascota) {
  try {
    const camposRequeridos = [
      "nombre",
      "especie",
      "raza",
      "edad",
      "peso",
      "chip",
      "duenioId",
      "direccion",
      "telefonoContacto",
    ]
    for (const campo of camposRequeridos) {
      if (!dataMascota[campo]) {
        return { success: false, error: `El campo ${campo} es obligatorio` }
      }
    }

    const validacionChip = await validarChipUnico(dataMascota.chip)
    if (validacionChip.existe) {
      return { success: false, error: "Este chip ya esta registrado en el sistema" }
    }

    const idInterno = generarIdInternoMascota()

    if (USE_MOCK) {
      await delay(600)

      const nuevaMascota = {
        id: `mascota-${Date.now()}`,
        idInterno,
        duenioId: dataMascota.duenioId,
        dueniosAsociados: [], // Inicializar array vacio
        nombre: dataMascota.nombre.trim(),
        especie: dataMascota.especie,
        raza: dataMascota.raza.trim(),
        edad: Number(dataMascota.edad),
        peso: Number(dataMascota.peso),
        sexo: dataMascota.sexo || "No especificado",
        chip: dataMascota.chip.toUpperCase().trim(),
        observaciones: dataMascota.observaciones || "",
        foto: dataMascota.foto || "/a-cute-pet.png",
        direccion: dataMascota.direccion.trim(),
        telefonoContacto: dataMascota.telefonoContacto.trim(),
        createdAt: new Date().toISOString(),
        historialMedico: [],
      }

      mascotasData.unshift(nuevaMascota)

      return {
        success: true,
        data: nuevaMascota,
        mensaje: `Companero ${nuevaMascota.nombre} registrado con ID: ${idInterno}`,
      }
    }

    const nuevaMascotaData = {
      idInterno,
      duenioId: dataMascota.duenioId,
      dueniosAsociados: [], // Inicializar array vacio
      nombre: dataMascota.nombre.trim(),
      especie: dataMascota.especie,
      raza: dataMascota.raza.trim(),
      edad: Number(dataMascota.edad),
      peso: Number(dataMascota.peso),
      sexo: dataMascota.sexo || "No especificado",
      chip: dataMascota.chip.toUpperCase().trim(),
      observaciones: dataMascota.observaciones || "",
      foto: dataMascota.foto || "/a-cute-pet.png",
      direccion: dataMascota.direccion.trim(),
      telefonoContacto: dataMascota.telefonoContacto.trim(),
      createdAt: serverTimestamp(),
    }

    const docRef = await addDoc(collection(db, "mascotas"), nuevaMascotaData)

    return {
      success: true,
      data: {
        id: docRef.id,
        ...nuevaMascotaData,
        createdAt: new Date().toISOString(),
        historialMedico: [],
      },
      mensaje: `Companero ${nuevaMascotaData.nombre} registrado con ID: ${idInterno}`,
    }
  } catch (error) {
    console.error("[API] Error al crear mascota:", error)
    return { success: false, error: "Error al registrar companero" }
  }
}

/* ================================================================
   HISTORIAL MEDICO / PROCEDIMIENTOS
   ================================================================ */

export async function getHistorialByMascotaDocId(mascotaDocId) {
  try {
    if (!mascotaDocId) {
      return { success: false, error: "ID de companero requerido", data: [] }
    }

    if (USE_MOCK) {
      await delay(300)
      const historial = historialesData
        .filter((h) => h.mascotaDocId === mascotaDocId || h.mascotaId === mascotaDocId)
        .sort((a, b) => new Date(b.fecha + " " + (b.hora || "00:00")) - new Date(a.fecha + " " + (a.hora || "00:00")))
      return { success: true, data: historial }
    }

    const q = query(collection(db, "historiales"), where("mascotaDocId", "==", mascotaDocId), orderBy("fecha", "desc"))

    const querySnapshot = await getDocs(q)
    const historial = querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))

    return { success: true, data: historial }
  } catch (error) {
    console.error("[API] Error al obtener historial:", error)
    return { success: false, error: "Error al cargar historial", data: [] }
  }
}

export async function crearProcedimiento(dataProcedimiento) {
  try {
    const camposRequeridos = ["mascotaDocId", "procedimiento", "descripcion", "medico", "clinica", "fecha", "hora"]
    for (const campo of camposRequeridos) {
      if (!dataProcedimiento[campo]) {
        return { success: false, error: `El campo ${campo} es obligatorio` }
      }
    }

    let tipo = "Consulta"
    const procLower = dataProcedimiento.procedimiento.toLowerCase()
    if (procLower.includes("vacuna") || procLower.includes("inmunizacion")) {
      tipo = "Vacuna"
    } else if (procLower.includes("cirugia") || procLower.includes("operacion") || procLower.includes("extraccion")) {
      tipo = "Cirugia"
    }

    if (USE_MOCK) {
      await delay(500)

      const nuevoRegistro = {
        id: `hist-${Date.now()}`,
        mascotaDocId: dataProcedimiento.mascotaDocId,
        mascotaId: dataProcedimiento.mascotaDocId,
        tipo,
        procedimiento: dataProcedimiento.procedimiento,
        descripcion: dataProcedimiento.descripcion,
        medico: dataProcedimiento.medico,
        clinica: dataProcedimiento.clinica,
        fecha: dataProcedimiento.fecha,
        hora: dataProcedimiento.hora,
        createdAt: new Date().toISOString(),
      }

      historialesData.unshift(nuevoRegistro)
      return { success: true, data: nuevoRegistro }
    }

    const nuevoRegistroData = {
      mascotaDocId: dataProcedimiento.mascotaDocId,
      tipo,
      procedimiento: dataProcedimiento.procedimiento,
      descripcion: dataProcedimiento.descripcion,
      medico: dataProcedimiento.medico,
      clinica: dataProcedimiento.clinica,
      fecha: dataProcedimiento.fecha,
      hora: dataProcedimiento.hora,
      createdAt: serverTimestamp(),
    }

    const docRef = await addDoc(collection(db, "historiales"), nuevoRegistroData)

    return {
      success: true,
      data: {
        id: docRef.id,
        ...nuevoRegistroData,
        createdAt: new Date().toISOString(),
      },
    }
  } catch (error) {
    console.error("[API] Error al crear procedimiento:", error)
    return { success: false, error: "Error al registrar procedimiento" }
  }
}

/* ================================================================
   DESCARGA DE FICHA
   ================================================================ */

export async function descargarFichaPorChip(chip) {
  try {
    const resultado = await buscarMascotaPorChip(chip)
    if (!resultado.success) {
      return resultado
    }

    const mascota = resultado.data
    const historial = mascota.historialMedico || []

    let contenido = `
═══════════════════════════════════════════════════════════
                    FICHA MEDICA VETERINARIA
                         InfoVet Chile
═══════════════════════════════════════════════════════════

DATOS DEL COMPANERO
───────────────────────────────────────────────────────────
Nombre:          ${mascota.nombre}
Especie:         ${mascota.especie}
Raza:            ${mascota.raza}
Edad:            ${mascota.edad} años
Peso:            ${mascota.peso} kg
Sexo:            ${mascota.sexo || "No especificado"}
N° Chip:         ${mascota.chip}
ID Sistema:      ${mascota.idInterno || "N/A"}

UBICACION DEL COMPANERO
───────────────────────────────────────────────────────────
Direccion:       ${mascota.direccion || "No registrada"}
Telefono:        ${mascota.telefonoContacto || "No registrado"}

DUENO REGISTRADO
───────────────────────────────────────────────────────────
Nombre:          ${mascota.dueno?.nombre || "No registrado"}
Email:           ${mascota.dueno?.email || "No registrado"}
Telefono:        ${mascota.dueno?.telefono || "No registrado"}

HISTORIAL CLINICO
═══════════════════════════════════════════════════════════
`

    if (historial.length === 0) {
      contenido += "\nNo hay registros medicos.\n"
    } else {
      historial.forEach((registro, index) => {
        contenido += `
[${index + 1}] ${registro.procedimiento || registro.tipo}
    Fecha: ${registro.fecha}${registro.hora ? ` - ${registro.hora}` : ""}
    Tipo: ${registro.tipo}
    Descripcion: ${registro.descripcion}
    Medico: ${registro.medico || registro.veterinario}
    Clinica: ${registro.clinica}
───────────────────────────────────────────────────────────`
      })
    }

    contenido += `

═══════════════════════════════════════════════════════════
Documento generado el ${new Date().toLocaleString("es-CL")}
InfoVet - Sistema de Fichas Medicas Veterinarias
═══════════════════════════════════════════════════════════
`

    const blob = new Blob([contenido], { type: "text/plain;charset=utf-8" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `ficha_${mascota.nombre}_${mascota.chip}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    return { success: true, mensaje: "Ficha descargada exitosamente" }
  } catch (error) {
    console.error("[API] Error al descargar ficha:", error)
    return { success: false, error: "Error al generar la ficha" }
  }
}

/**
 * Actualiza companero con validacion de permisos RBAC
 * @param {string} companeroId - ID del companero
 * @param {object} data - Datos a actualizar
 * @param {string} userRole - Rol del usuario que realiza la actualizacion
 * @param {string} userId - ID del usuario que realiza la actualizacion
 */
export async function updateCompanero(companeroId, data, userRole, userId) {
  try {
    if (!companeroId || !userRole) {
      return { success: false, error: "Parametros invalidos" }
    }

    // Filtrar datos segun permisos del rol
    const datosFiltrados = filtrarDatosEditables(data, userRole)

    if (Object.keys(datosFiltrados).length === 0) {
      return { success: false, error: "No tienes permisos para editar estos campos" }
    }

    if (USE_MOCK) {
      await delay(400)

      const index = mascotasData.findIndex((m) => m.id === companeroId)
      if (index === -1) {
        return { success: false, error: "Companero no encontrado" }
      }

      const companero = mascotasData[index]

      // Aplicar actualizaciones segun estructura
      for (const [campo, valor] of Object.entries(datosFiltrados)) {
        // Verificar si el campo esta en infoBasica
        if (companero.infoBasica && companero.infoBasica.hasOwnProperty(campo)) {
          companero.infoBasica[campo] = valor
        }
        // Verificar si el campo esta en infoClinica
        else if (companero.infoClinica && companero.infoClinica.hasOwnProperty(campo)) {
          companero.infoClinica[campo] = valor
        }
        // Campos de nivel raiz
        else {
          companero[campo] = valor
        }
      }

      companero.updatedAt = new Date().toISOString()

      return { success: true, data: companero, mensaje: "Companero actualizado correctamente" }
    }

    // Firebase implementation
    const companeroRef = doc(db, "mascotas", companeroId)
    const updateData = { ...datosFiltrados, updatedAt: serverTimestamp() }

    await updateDoc(companeroRef, updateData)

    return { success: true, data: updateData, mensaje: "Companero actualizado correctamente" }
  } catch (error) {
    console.error("[API] Error al actualizar companero:", error)
    return { success: false, error: "Error al actualizar companero" }
  }
}

/**
 * Busca companero por chip (busqueda global)
 */
export async function searchCompaneroByChip(chipNumber) {
  try {
    if (!chipNumber) {
      return { success: false, error: "Numero de chip requerido" }
    }

    const chipBusqueda = chipNumber.toUpperCase().trim()

    if (USE_MOCK) {
      await delay(300)
      const companero = mascotasData.find((m) => m.chip.toUpperCase() === chipBusqueda)

      if (!companero) {
        return { success: false, error: "Companero no encontrado", data: null }
      }

      // Incluir historial
      const historial = historialesData.filter((h) => h.mascotaDocId === companero.id)
      const companeroConHistorial = { ...companero, historialMedico: historial }

      return { success: true, data: companeroConHistorial }
    }

    const q = query(collection(db, "mascotas"), where("chip", "==", chipBusqueda))
    const querySnapshot = await getDocs(q)

    if (querySnapshot.empty) {
      return { success: false, error: "Companero no encontrado", data: null }
    }

    const companeroDoc = querySnapshot.docs[0]
    const companero = { id: companeroDoc.id, ...companeroDoc.data() }

    // Incluir historial
    const historialQuery = query(collection(db, "historiales"), where("mascotaDocId", "==", companeroDoc.id))
    const historialSnapshot = await getDocs(historialQuery)
    companero.historialMedico = historialSnapshot.docs.map((h) => ({ id: h.id, ...h.data() }))

    return { success: true, data: companero }
  } catch (error) {
    console.error("[API] Error al buscar por chip:", error)
    return { success: false, error: "Error en la busqueda", data: null }
  }
}

/**
 * Vincula companero a usuario (agregar a pacientes/companeros)
 */
export async function linkCompaneroToUser(companeroId, userId) {
  try {
    if (!companeroId || !userId) {
      return { success: false, error: "Parametros invalidos" }
    }

    if (USE_MOCK) {
      await delay(300)

      const companero = mascotasData.find((m) => m.id === companeroId)
      if (!companero) {
        return { success: false, error: "Companero no encontrado" }
      }

      // Verificar si ya esta vinculado
      if (!companero.dueniosAsociados) {
        companero.dueniosAsociados = []
      }

      if (companero.dueniosAsociados.includes(userId)) {
        return { success: false, error: "Este companero ya esta en tu lista" }
      }

      companero.dueniosAsociados.push(userId)

      // Incluir historial
      const historial = historialesData.filter((h) => h.mascotaDocId === companero.id)
      const companeroConHistorial = { ...companero, historialMedico: historial }

      return {
        success: true,
        data: companeroConHistorial,
        mensaje: `${companero.infoBasica.nombre} agregado a tus companeros`,
      }
    }

    const companeroRef = doc(db, "mascotas", companeroId)
    const companeroSnap = await getDoc(companeroRef)

    if (!companeroSnap.exists()) {
      return { success: false, error: "Companero no encontrado" }
    }

    const companero = { id: companeroSnap.id, ...companeroSnap.data() }

    if (companero.dueniosAsociados && companero.dueniosAsociados.includes(userId)) {
      return { success: false, error: "Este companero ya esta en tu lista" }
    }

    await updateDoc(companeroRef, {
      dueniosAsociados: arrayUnion(userId),
      updatedAt: serverTimestamp(),
    })

    companero.dueniosAsociados = [...(companero.dueniosAsociados || []), userId]

    return { success: true, data: companero, mensaje: `${companero.infoBasica.nombre} agregado a tus companeros` }
  } catch (error) {
    console.error("[API] Error al vincular companero:", error)
    return { success: false, error: "Error al vincular companero" }
  }
}

/**
 * Obtiene companeros segun rol del usuario
 */
export async function getCompanerosByUsuario(userId, userRol = "dueno") {
  try {
    if (!userId) {
      return { success: false, error: "Usuario no autenticado", data: [] }
    }

    if (USE_MOCK) {
      await delay(300)
      let mascotas

      // Veterinario, Fundacion y Admin ven todos
      if (tienePermiso(userRol, "VER_TODOS_COMPANEROS")) {
        mascotas = mascotasData
      } else {
        // Dueno solo ve los suyos y asociados
        mascotas = mascotasData.filter(
          (m) => m.tutorActualId === userId || (m.dueniosAsociados && m.dueniosAsociados.includes(userId)),
        )
      }

      const mascotasConHistorial = mascotas.map((m) => ({
        ...m,
        historialMedico: historialesData.filter((h) => h.mascotaDocId === m.id || h.mascotaId === m.id),
      }))
      return { success: true, data: mascotasConHistorial }
    }

    // Firebase implementation
    let q

    if (tienePermiso(userRol, "VER_TODOS_COMPANEROS")) {
      q = query(collection(db, "mascotas"), orderBy("createdAt", "desc"))
    } else {
      q = query(collection(db, "mascotas"), where("tutorActualId", "==", userId), orderBy("createdAt", "desc"))
    }

    const querySnapshot = await getDocs(q)
    const mascotas = await Promise.all(
      querySnapshot.docs.map(async (docSnap) => {
        const mascotaData = { id: docSnap.id, ...docSnap.data() }
        const historialQuery = query(
          collection(db, "historiales"),
          where("mascotaDocId", "==", docSnap.id),
          orderBy("fecha", "desc"),
        )
        const historialSnapshot = await getDocs(historialQuery)
        mascotaData.historialMedico = historialSnapshot.docs.map((h) => ({ id: h.id, ...h.data() }))
        return mascotaData
      }),
    )

    // Incluir companeros asociados para duenos
    if (userRol === ROLES.DUENO) {
      const qAsociados = query(collection(db, "mascotas"), where("dueniosAsociados", "array-contains", userId))
      const asociadosSnapshot = await getDocs(qAsociados)

      for (const docSnap of asociadosSnapshot.docs) {
        if (!mascotas.find((m) => m.id === docSnap.id)) {
          const mascotaData = { id: docSnap.id, ...docSnap.data() }
          const historialQuery = query(
            collection(db, "historiales"),
            where("mascotaDocId", "==", docSnap.id),
            orderBy("fecha", "desc"),
          )
          const historialSnapshot = await getDocs(historialQuery)
          mascotaData.historialMedico = historialSnapshot.docs.map((h) => ({ id: h.id, ...h.data() }))
          mascotas.push(mascotaData)
        }
      }
    }

    return { success: true, data: mascotas }
  } catch (error) {
    console.error("[API] Error al obtener companeros:", error)
    return { success: false, error: "Error al cargar companeros", data: [] }
  }
}

export async function verificarChip(companeroId, numeroChip, veterinarioId) {
  try {
    if (!companeroId || !numeroChip || !veterinarioId) {
      return { success: false, error: "Parametros invalidos" }
    }

    if (USE_MOCK) {
      await delay(600)

      const index = mascotasData.findIndex((m) => m.id === companeroId)
      if (index === -1) {
        return { success: false, error: "Companero no encontrado" }
      }

      const companero = mascotasData[index]

      companero.chipVerificado = true
      companero.verificadoPor = veterinarioId
      companero.verificadoEn = new Date().toISOString()
      companero.updatedAt = new Date().toISOString()

      return {
        success: true,
        data: companero,
        mensaje: "Chip verificado correctamente",
      }
    }

    // Firebase implementation
    const companeroRef = doc(db, "mascotas", companeroId)
    const updateData = {
      chipVerificado: true,
      verificadoPor: veterinarioId,
      verificadoEn: serverTimestamp(),
      updatedAt: serverTimestamp(),
    }

    await updateDoc(companeroRef, updateData)

    return { success: true, data: updateData, mensaje: "Chip verificado correctamente" }
  } catch (error) {
    console.error("[API] Error al verificar chip:", error)
    return { success: false, error: "Error al verificar chip" }
  }
}
