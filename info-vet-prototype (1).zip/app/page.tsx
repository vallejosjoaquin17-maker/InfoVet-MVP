"use client"

import { AuthProvider } from "@/src/context/AuthContext"
import InfoVetApp from "@/src/App"

export default function Page() {
  return (
    <AuthProvider>
      <InfoVetApp />
    </AuthProvider>
  )
}
